module.exports = {
    db: {
        developement: "mongodb://localhost/User"
    },
    dbParam: {
        useNewUrlParser: true,
        useCreateIndex: true,
        useFindAndModify: false,
    }
}