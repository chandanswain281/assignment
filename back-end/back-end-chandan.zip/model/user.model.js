const mongoose = require('mongoose')

var  userSchema = new mongoose.Schema({
    _id: mongoose.Schema.Types.ObjectId,
    Name: {
        type: mongoose.Schema.Types.String,
        required: true,
        trim: true
    },
    Email: {
        type: mongoose.Schema.Types.String,
        required: true,
        trim: true
    },
    Address: {
        type: mongoose.Schema.Types.String,
        required: true,
        trim: true
    },
    Hobbie: {
        type: mongoose.Schema.Types.Boolean,
        required: true,
    },
    education: {
        type: mongoose.Schema.Types.Boolean,
        required: true,
    },
})

module.exports.userModel = mongoose.model('Users',userSchema)